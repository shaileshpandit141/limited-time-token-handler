class TokenError(Exception):
    """Custom exception for token errors."""

    pass
